export default interface IConfig {
  serviceUrl: string;
}