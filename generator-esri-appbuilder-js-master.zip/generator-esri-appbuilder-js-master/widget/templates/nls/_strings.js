define({
  root: {
    _widgetLabel: '<%= widgetTitle %>',
    widgetTitle: '<%= widgetTitle %>',
    description: '<%= description %>'
  }
  // add supported locales below:
  // , "zh-cn": true
});
