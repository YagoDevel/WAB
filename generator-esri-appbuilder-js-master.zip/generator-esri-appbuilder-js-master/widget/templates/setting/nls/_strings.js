define({
  root: ({
    serviceUrl: 'Set service url:'
  })
});
